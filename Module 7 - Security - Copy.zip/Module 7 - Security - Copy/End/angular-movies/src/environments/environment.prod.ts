export const environment = {
  production: true,
  apiURL: 'https://localhost:44347/api'
};
